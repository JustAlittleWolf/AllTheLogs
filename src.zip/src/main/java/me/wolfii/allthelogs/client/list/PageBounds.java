package me.wolfii.allthelogs.client.list;

import me.wolfii.allthelogs.api.ChatQuery;
import me.wolfii.allthelogs.api.MatchDay;
import me.wolfii.allthelogs.data.ChatEntry;
import me.wolfii.allthelogs.data.MatchSummary;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Decides what lies beyond the page that just arrived: whether more matches exist before or after it, whether
 * it fills the viewport, and which cursor the next page should start from.
 * <p>
 * The store pages by a row cursor {@code (time, file, line)} rather than by row offset, because rows shift
 * as logs are imported. Timestamp-only exclusive offsets are still used to jump to a clock time. That
 * makes "is there more?" a comparison against the unpaged {@link MatchSummary} instead of a row count.
 */
public final class PageBounds {
    private PageBounds() {
    }

    /**
     * DuckDB {@code TIMESTAMP} stores microseconds. A 1-nanosecond nudge is truncated, so a descending
     * {@code entry_time < cursor} already excludes the cursor second and {@code OFFSET skip} then drops
     * the next older message.
     */
    private static final int CURSOR_STEP_NANOS = 1_000;

    /**
     * Cursor that starts a page at {@code time} itself. Cursors are exclusive, so it has to be nudged one
     * microsecond past {@code time} against the sort direction.
     */
    public static LocalDateTime exclusiveOffset(LocalDateTime time, ChatQuery.Sort sort) {
        if (sort == ChatQuery.Sort.DESCENDING) {
            return time.plusNanos(CURSOR_STEP_NANOS);
        }
        return time.minusNanos(CURSOR_STEP_NANOS);
    }

    /**
     * Continues a paged query after {@code edge} without dropping other matches that share that
     * second. The store cursor is exclusive on {@code (time, file, line)}, so later (or earlier)
     * lines at the same timestamp are still returned and {@code edge} itself is not.
     */
    public static ChatQuery continueFrom(ChatQuery page, DisplayRow edge) {
        return continueFrom(page, edge.entry());
    }

    /**
     * Same as {@link #continueFrom(ChatQuery, DisplayRow)} when the caller already has the stored
     * line rather than a display row.
     */
    public static ChatQuery continueFrom(ChatQuery page, ChatEntry edge) {
        return page.withOffset(edge.timestamp(), edge.chatLog().source(), edge.lineIndex());
    }

    /**
     * Whether matches exist before this page, judged against the whole matched range.
     * {@code skipped} is the match rank a timeline jump already walked past; those rows sit
     * before the page even when they share its first timestamp.
     */
    public static boolean hasBefore(ChatQuery.Sort sort, List<DisplayRow> rows, MatchSummary summary,
                                    long skipped) {
        return skipped > 0 || hasBefore(sort, rows, summary);
    }

    /**
     * Whether matches exist before this page, judged against the whole matched range.
     */
    public static boolean hasBefore(ChatQuery.Sort sort, List<DisplayRow> rows, MatchSummary summary) {
        LocalDateTime first = DisplayRows.firstMatchTime(rows);
        if (first == null || summary == null) return false;
        if (sort == ChatQuery.Sort.ASCENDING) {
            return summary.oldest() != null && summary.oldest().isBefore(first);
        }
        return summary.newest() != null && summary.newest().isAfter(first);
    }

    /**
     * Whether matches exist after this page. A page that hit its own limit always has more.
     */
    public static boolean hasAfter(ChatQuery.Sort sort, boolean full, List<DisplayRow> rows, MatchSummary summary) {
        if (full) return true;
        LocalDateTime last = DisplayRows.lastMatchTime(rows);
        if (last == null || summary == null) return false;
        if (sort == ChatQuery.Sort.ASCENDING) {
            return summary.newest() != null && summary.newest().isAfter(last);
        }
        return summary.oldest() != null && summary.oldest().isBefore(last);
    }

    /**
     * Whether the page returned as many matches as it asked for, so more are waiting.
     */
    public static boolean isFull(List<DisplayRow> rows, long limit) {
        return limit > 0 && DisplayRows.matchCount(rows) >= limit;
    }

    /**
     * A jump that lands on the newest (or oldest) matches can return too few rows to fill the list, because
     * {@link #exclusiveOffset} starts the page at that timestamp and there is nothing beyond it. Older (or
     * newer) rows have to be fetched first in that case.
     */
    public static boolean needsMoreToFill(List<DisplayRow> rows, int contextLines, int viewHeight,
                                          boolean hasBefore) {
        if (!hasBefore || rows == null || rows.isEmpty() || viewHeight <= 0) return false;
        return MessageListLayout.of(rows, contextLines).contentHeight() < viewHeight;
    }

    /**
     * How many matches to fetch to fill a viewport of {@code viewHeight}, never fewer than a screenful of
     * single-line rows plus a margin.
     */
    public static int extraFillLimit(int viewHeight, long pageLimit) {
        int needed = Math.max(8, viewHeight / MessageListLayout.ROW_HEIGHT + 8);
        if (pageLimit < 0) return needed;
        return (int) Math.max(needed, Math.min(pageLimit, Integer.MAX_VALUE));
    }

    /**
     * Whether the thumb can map 0–1 progress onto the rows already buffered for {@code day}.
     * <p>
     * A scrubber preview only loads a slice. Treating that slice as the whole day would scroll inside it
     * instead of fetching, so a line at the edge of the original page (the newest live message, for
     * example) would disappear. After a fetch, {@code onFetchedPage} is set so the new slice can still
     * be positioned. A collapsed day addressed by match rank always jumps until every match is loaded.
     */
    public static boolean canScrollDayLocally(MatchDay day, int loadedMatchesOnDay, long skip,
                                              boolean onFetchedPage, boolean timeInBuffer) {
        if (day == null) return false;
        boolean allLoaded = loadedMatchesOnDay >= day.matches();
        if (day.collapsed() && skip >= 0 && !allLoaded) return false;
        return allLoaded || onFetchedPage || timeInBuffer;
    }
}
