package me.wolfii.allthelogs.client;

import me.wolfii.allthelogs.data.ImportOptions;
import me.wolfii.allthelogs.data.LogSource;
import me.wolfii.allthelogs.data.store.SessionMarker;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Fabric client entry: opens the log store, imports this instance's {@code logs} folder, captures live chat,
 * and registers {@code /allthelogs gui} and {@code /allthelogs import}.
 */
public final class AllTheLogsClient implements ClientModInitializer {
    public static final String MOD_ID = "allthelogs";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static final long SESSION_END_TOUCH_INTERVAL_MS = 60_000L;
    private static final AtomicBoolean storeStarted = new AtomicBoolean();
    private static LogStoreWorker worker;
    private static long lastSessionEndTouchMs;

    public static LogStoreWorker worker() {
        return worker;
    }

    private static void capture(Component message) {
        worker.importSessionMessage(message);
    }

    private static CompletableFuture<Void> importCurrentLogs() {
        Path gameDir = AllTheLogsPaths.gameDirectory();
        Path logs = gameDir.resolve("logs");
        Path root;
        ImportOptions options;
        if (Files.isDirectory(logs)) {
            root = logs;
            options = ImportOptions.currentLogsDirectory();
        } else if (Files.isDirectory(gameDir)) {
            root = gameDir;
            options = ImportOptions.currentGameDirectory();
        } else {
            return CompletableFuture.completedFuture(null);
        }
        return worker.importDirectory(root, options, null)
            .thenAccept(result -> LOGGER.info(
                "Imported instance logs: {} files, {} entries ({} skipped)",
                result.importedFiles(), result.importedEntries(), result.skippedFiles()));
    }

    private static String minecraftVersion() {
        return FabricLoader.getInstance().getModContainer("minecraft")
            .map(container -> container.getMetadata().getVersion().getFriendlyString())
            .orElse("unknown");
    }

    private static String currentUsername() {
        Minecraft client = Minecraft.getInstance();
        if (client == null) return null;
        var user = client.getUser();
        if (user == null) return null;
        String name = user.getName();
        return name == null || name.isBlank() ? null : name;
    }

    /**
     * Opens the log store after the DuckDB native library is on the classpath.
     */
    public static void onDriverReady() {
        if (worker == null || !storeStarted.compareAndSet(false, true)) return;
        worker.open(AllTheLogsPaths.database())
            .thenCompose(ignored -> importCurrentLogs())
            .thenCompose(ignored -> worker.startSession(minecraftVersion(), currentUsername()))
            .whenComplete((log, error) -> {
                if (error != null) {
                    LOGGER.error("AllTheLogs failed to start", error);
                    return;
                }
                if (log != null && log.source() instanceof LogSource.Session session && session.id() != null) {
                    LOGGER.info(SessionMarker.message(session.id()));
                }
            });
    }

    @Override
    public void onInitializeClient() {
        worker = new LogStoreWorker();
        DuckDbRuntime.ensure().thenRun(AllTheLogsClient::onDriverReady);

        ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, timestamp) -> capture(message));
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) capture(message);
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            AllTheLogsCommands.register(dispatcher));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            long now = System.currentTimeMillis();
            if (now - lastSessionEndTouchMs < SESSION_END_TOUCH_INTERVAL_MS) return;
            lastSessionEndTouchMs = now;
            worker.touchSessionEndTime();
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> worker.close());
    }
}
